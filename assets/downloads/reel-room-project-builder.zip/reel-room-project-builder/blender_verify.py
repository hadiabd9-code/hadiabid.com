"""Check built shot files against the job that made them (runs inside Blender).

  blender -b --factory-startup --python blender_verify.py -- build/jobs/job_<pid>_<stamp>.json

Opens each shot .blend and checks scene name, frame range, fps, resolution,
scene camera, and that every linked library exists on disk, is stored as a
relative path, and gives the expected collection instance. Prints PASS/FAIL
per shot and exits 1 on any failure.

Layout shots (job shot has "layout", 2026-10-26) are checked against their
recipe instead of the side-by-side instances: every placed asset is there
(instance empty or library override, still linked to its library), camera
lens + keys on the first and last frame, alt cameras, board panels as camera
background images (files found, relative), panel alpha keys, sound strip,
LAYOUT_NOTES text.

Layout v002 (2026-10-27): optional recipe["verify"] adds LINEAR-curve, camera
parent / Track To, framing (target stays in a frame box on every frame),
hidden-part and travel checks: see check_extra().
"""
import json
import os
import sys

import bpy

try:
    from bpy_extras.anim_utils import action_get_channelbag_for_slot
except ImportError:  # older Blender
    action_get_channelbag_for_slot = None


def key_frames(id_data, path_prefix=""):
    """Sorted keyed frames on an ID (any fcurve whose data path starts with path_prefix)."""
    ad = id_data.animation_data
    if not ad or not ad.action:
        return []
    act = ad.action
    if action_get_channelbag_for_slot and getattr(ad, "action_slot", None):
        cb = action_get_channelbag_for_slot(act, ad.action_slot)
        fcs = cb.fcurves if cb else []
    else:
        fcs = getattr(act, "fcurves", [])
    return sorted({round(k.co[0]) for fc in fcs if fc.data_path.startswith(path_prefix) for k in fc.keyframe_points})


def check_layout(sh, sc):
    lay, bad, got = sh["layout"], [], {}
    cam = sc.camera
    c = lay.get("camera", {})
    got["lens"] = round(cam.data.lens, 2) if cam else None
    first_lens = c.get("keys", [{}])[0].get("lens", c.get("lens", 50))
    if cam and len(c.get("keys", [])) > 1:
        kf = key_frames(cam, "location") + key_frames(cam, "rotation")
        got["cam_keys"] = [min(kf), max(kf), len(set(kf))] if kf else []
        if not kf or min(kf) != sh["frame_start"] or max(kf) != sh["frame_end"]:
            bad.append(f"camera keys {got['cam_keys']} not on first/last frame {sh['frame_start']}/{sh['frame_end']}")
    sc.frame_set(sh["frame_start"])
    if cam and abs(cam.data.lens - first_lens) > 0.01:
        bad.append(f"lens {cam.data.lens} != {first_lens}")
    for alt in lay.get("alt_cameras", []):
        if alt["name"] not in bpy.data.objects:
            bad.append(f"no alt camera {alt['name']}")
    got["alt"] = [a["name"] for a in lay.get("alt_cameras", [])]

    # instance empties carry sg_instance; overrides are found by their root part name
    # (custom props added to an override are not saved)
    placed = {o.get("sg_instance") for o in sc.objects if o.get("sg_instance")}
    ov_roots = {o.name for o in sc.objects if o.override_library}
    missing = [e["name"] for e in lay.get("instances", [])
               if (e.get("root", f"{e['asset']}_root") not in ov_roots if e.get("override") else e["name"] not in placed)]
    placed |= {e["name"] for e in lay.get("instances", []) if e.get("override") and e["name"] not in missing}
    if missing:
        bad.append(f"not placed: {missing}")
    for o in sc.objects:
        if o.override_library and not o.override_library.reference:
            bad.append(f"{o.name}: override lost its library reference")
    got["placed"] = len(placed)
    got["overrides"] = sum(1 for o in sc.objects if o.override_library)

    bgs = cam.data.background_images if cam else []
    got["panels"] = len(bgs)
    if len(bgs) != len(lay.get("panels", [])):
        bad.append(f"{len(bgs)} background images, want {len(lay.get('panels', []))}")
    for b in bgs:
        fp = b.image.filepath if b.image else ""
        if not fp or not os.path.exists(bpy.path.abspath(fp)):
            bad.append(f"panel missing: {fp}")
        elif not fp.startswith("//"):
            bad.append(f"panel path not relative: {fp}")
    if len(bgs) > 1:
        ak = key_frames(cam.data, "background_images")
        got["panel_keys"] = ak
        if not ak:
            bad.append("panel alpha not keyed")
    if lay.get("sound"):
        se = sc.sequence_editor
        strips = list(se.strips_all) if se else []
        snd = [s for s in strips if s.type == "SOUND"]
        got["sound"] = [os.path.basename(s.sound.filepath) for s in snd]
        if not snd or not os.path.exists(bpy.path.abspath(snd[0].sound.filepath)):
            bad.append("sound strip missing or file not found")
        elif not snd[0].sound.filepath.startswith("//"):
            bad.append(f"sound path not relative: {snd[0].sound.filepath}")
    if lay.get("notes") and "LAYOUT_NOTES" not in bpy.data.texts:
        bad.append("no LAYOUT_NOTES text")
    if lay.get("verify") and cam:
        vgot, vbad = check_extra(sh, sc, cam, lay["verify"])
        got.update(vgot)
        bad += vbad
    return got, bad


def obj_named(sc, name):
    """Scene object by name ('camera' = the scene camera); overrides may carry a .001 suffix."""
    if name == "camera":
        return sc.camera
    for o in sc.objects:
        if o.name == name:
            return o
    return next((o for o in sc.objects if o.name.split(".")[0] == name), None)


def fcurves(id_data):
    ad = id_data.animation_data
    if not ad or not ad.action:
        return []
    if action_get_channelbag_for_slot and getattr(ad, "action_slot", None):
        cb = action_get_channelbag_for_slot(ad.action, ad.action_slot)
        return list(cb.fcurves) if cb else []
    return list(getattr(ad.action, "fcurves", []))


def check_extra(sh, sc, cam, v):
    """Layout v002 checks (2026-10-27), from recipe["verify"]:
      linear: [objects]           every location/rotation key is LINEAR (flight + camera curves)
      parent: object              the scene camera is parented to it (camera rides with the aircraft)
      track: true                 the camera aims with a Track To constraint (target exists)
      in_frame: [{obj, offset?, box? [x0,x1,y0,y1], frames? all|last, max_travel?}]
                                  the point stays inside the box (0-1 camera view, default the whole frame)
                                  on every frame; max_travel = how far it may move across the frame
      hidden: [objects]           hidden in render (e.g. the empty F/O seat in SH110)
      rel_travel: [[a, b, min_m]] a and b move apart by at least min_m (not locked together)
      min_travel: [[obj, min_m]]  obj moves at least min_m in world space (aircraft is moving)
      done_by: [[obj, data_path, frame]]  the last key on that channel is at or before frame
                                  (e.g. SH060 prop fully feathered by f465 for the sound)
    """
    from bpy_extras.object_utils import world_to_camera_view
    from mathutils import Vector

    got, bad = {}, []
    f0, f1 = sh["frame_start"], sh["frame_end"]
    for name in v.get("linear", []):
        o = obj_named(sc, name)
        if o is None:
            bad.append(f"linear: no object {name}")
            continue
        interps = {k.interpolation for fc in fcurves(o) if fc.data_path in ("location", "rotation_euler")
                   for k in fc.keyframe_points}
        got[f"interp_{name}"] = sorted(interps)
        if interps != {"LINEAR"}:
            bad.append(f"{name}: keys not all LINEAR ({sorted(interps)})")
    if v.get("parent"):
        par = cam.parent.name if cam.parent else None
        got["cam_parent"] = par
        if not par or par.split(".")[0] != v["parent"]:
            bad.append(f"camera parent {par} != {v['parent']}")
    if v.get("track"):
        tc = [c for c in cam.constraints if c.type == "TRACK_TO" and c.target]
        got["cam_track"] = tc[0].target.name if tc else None
        if not tc:
            bad.append("camera has no Track To constraint with a target")
    for name, path, fmax in v.get("done_by", []):
        o = obj_named(sc, name)
        ks = [k.co[0] for fc in (fcurves(o) if o else []) if fc.data_path == path for k in fc.keyframe_points]
        got[f"last_key_{name}"] = round(max(ks)) if ks else None
        if not ks or max(ks) > fmax:
            bad.append(f"{name}.{path}: last key {max(ks) if ks else None} after f{fmax}")
    for name in v.get("hidden", []):
        o = obj_named(sc, name)
        if o is None or not o.hide_render:
            bad.append(f"{name} not hidden" if o else f"hidden: no object {name}")
    got["hidden"] = v.get("hidden", [])

    frames = range(f0, f1 + 1)
    track = {}  # (name, i) -> [(x, y)] per frame
    pos = {}    # name -> [world location] per frame
    names = {n for a, b, _ in v.get("rel_travel", []) for n in (a, b)} | {n for n, _ in v.get("min_travel", [])}
    for f in frames:
        sc.frame_set(f)
        for i, t in enumerate(v.get("in_frame", [])):
            o = obj_named(sc, t["obj"])
            if o is None:
                continue
            p = o.matrix_world @ Vector(t.get("offset", (0, 0, 0)))
            c = world_to_camera_view(sc, cam, p)
            track.setdefault(i, []).append((f, c.x, c.y, c.z))
        for n in names:
            o = obj_named(sc, n)
            if o is not None:
                pos.setdefault(n, []).append(o.matrix_world.translation.copy())
    for i, t in enumerate(v.get("in_frame", [])):
        pts = track.get(i)
        label = t["obj"] + (f"+{t['offset']}" if t.get("offset") else "")
        if not pts:
            bad.append(f"in_frame: no object {t['obj']}")
            continue
        if t.get("frames") == "last":
            pts = pts[-1:]
        x0, x1, y0, y1 = t.get("box", [0, 1, 0, 1])
        out = [f for f, x, y, z in pts if not (x0 <= x <= x1 and y0 <= y <= y1 and z > 0)]
        xs, ys = [p[1] for p in pts], [p[2] for p in pts]
        travel = max(((xs[-1] - xs[0]) ** 2 + (ys[-1] - ys[0]) ** 2) ** 0.5, 0)
        got[f"frame_{label}"] = {"x": [round(min(xs), 3), round(max(xs), 3)], "y": [round(min(ys), 3), round(max(ys), 3)],
                                 "travel": round(travel, 3)}
        if out:
            bad.append(f"{label} leaves box {t.get('box', 'frame')} on {len(out)} frames (first f{out[0]})")
        if t.get("max_travel") is not None and travel > t["max_travel"]:
            bad.append(f"{label} travels {travel:.2f} of the frame (max {t['max_travel']})")
    for a, b, mn in v.get("rel_travel", []):
        if a not in pos or b not in pos:
            bad.append(f"rel_travel: missing {a} or {b}")
            continue
        rel = ((pos[a][-1] - pos[b][-1]) - (pos[a][0] - pos[b][0])).length
        got[f"rel_{a}_{b}"] = round(rel, 2)
        if rel < mn:
            bad.append(f"{a} vs {b} relative move {rel:.2f} m < {mn}")
    for n, mn in v.get("min_travel", []):
        if n not in pos:
            bad.append(f"min_travel: no {n}")
            continue
        d = (pos[n][-1] - pos[n][0]).length
        got[f"travel_{n}"] = round(d, 1)
        if d < mn:
            bad.append(f"{n} moves {d:.1f} m < {mn}")
    sc.frame_set(f0)
    return got, bad


job = json.load(open(sys.argv[sys.argv.index("--") + 1], encoding="utf-8"))
fails = 0
for sh in job["shots"]:
    if not os.path.exists(sh["path"]):
        print(f"FAIL {sh['code']}: no file {sh['path']}")
        fails += 1
        continue
    bpy.ops.wm.open_mainfile(filepath=sh["path"])
    sc = bpy.context.scene
    fps = sc.render.fps / sc.render.fps_base
    got = {
        "scene": sc.name,
        "frames": [sc.frame_start, sc.frame_end],
        "fps": round(fps, 3),
        "res": [sc.render.resolution_x, sc.render.resolution_y, sc.render.resolution_percentage],
        "camera": sc.camera.name if sc.camera else None,
        "libs": sorted(
            f"{os.path.basename(l.filepath)} rel={l.filepath.startswith('//')} found={os.path.exists(bpy.path.abspath(l.filepath))}"
            for l in bpy.data.libraries),
    }
    want = {
        "scene": sh["scene"], "frames": [sh["frame_start"], sh["frame_end"]], "fps": round(float(job["fps"]), 3),
        "res": [job["res"][0], job["res"][1], 100], "camera": sh["camera"],
        "libs": sorted(f"{os.path.basename(l['path'])} rel=True found=True" for l in sh["links"]),
    }
    if not sh.get("layout"):
        got["instances"] = sorted(o.instance_collection.name for o in sc.objects
                                  if o.instance_type == "COLLECTION" and o.instance_collection)
        want["instances"] = sorted(l["collection"] for l in sh["links"])
    bad = [k for k in want if got[k] != want[k]]
    if sh.get("layout"):
        got["fps_base"] = round(sc.render.fps_base, 6)
        lgot, lbad = check_layout(sh, sc)
        got.update(lgot)
        bad += lbad
    else:
        linked_ok = all(c.library is not None for c in bpy.data.collections if c.name in want["instances"])
        if not linked_ok:
            bad.append("collections not linked (local copies)")
    fails += bool(bad)
    print(f"{'FAIL' if bad else 'PASS'} {sh['code']}: {json.dumps(got)}" + (f"  BAD: {bad}" if bad else ""))
print(f"VERIFY {'OK' if not fails else f'{fails} FAILED'}: {len(job['shots'])} shots")
sys.exit(1 if fails else 0)
