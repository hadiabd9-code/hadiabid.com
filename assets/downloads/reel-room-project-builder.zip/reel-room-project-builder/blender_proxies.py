"""Grey block-in proxy assets (runs inside Blender, imported by blender_build.py).

A stub with "proxy": {"kind": "<name>", ...} in the job gets a real block-in
instead of the placeholder cube: real-world scale, metres, Z up, nose/front = +X.

Every proxy file has the asset collection <PROJ>_<code> with one root empty
`<code>_root` that every part hangs under (so a shot can override the asset
and key its parts by name). Extra sub-sets that a shot can instance on their
own are separate top-level collections in the same file
(e.g. H418_passengers_brace).

Kinds (first used for Halden 418, 2026-10-26):
  turboprop    34-seat high-wing twin turboprop, T-tail, gear in the nacelles
  figure       standing person 1.75-1.85 m, separate head/arms/legs, yellow
               nose marker on the face = facing (+X)
  passengers   seated cabin load (upright), + _brace and _walk sets
  cockpit      2-seat cockpit box, glareshield fire T-handles, windshield frame
  cabin        2+1 cabin, 34 seats, window openings, jump seat
  ramp / farmland / lake / field   ground sets
  fire_smoke   flame cone + smoke trail (+ hidden puff and wisp)
  vehicles     3 emergency vehicles with red/blue light bars

The aircraft numbers live in PLANE below; cockpit and cabin are built in the
aircraft's own coordinates (origin = CG on the fuselage axis), so a shot can
drop plane + cabin at the same transform and the wing shows through the windows.
"""
import math
import random

import bmesh
import bpy
from mathutils import Euler, Matrix, Vector

# Grey block-in palette (Workbench "Material" colour); accents only where they
# carry meaning (fire, water, warning lights, facing marker).
PALETTE = {
    "grey": (0.62, 0.62, 0.62), "light": (0.80, 0.80, 0.80), "mid": (0.48, 0.48, 0.48),
    "dark": (0.16, 0.16, 0.18), "slate": (0.27, 0.33, 0.40), "marker": (0.95, 0.80, 0.15),
    "red": (0.85, 0.08, 0.06), "blue": (0.10, 0.30, 0.95), "fire": (1.0, 0.45, 0.08),
    "smoke": (0.28, 0.28, 0.30), "puff": (0.97, 0.97, 0.97), "water": (0.33, 0.47, 0.66),
    "concrete": (0.66, 0.65, 0.62), "paint": (0.85, 0.74, 0.22), "white": (0.92, 0.92, 0.92),
    "stubble": (0.78, 0.74, 0.62), "f1": (0.52, 0.50, 0.44), "f2": (0.42, 0.44, 0.38),
    "f3": (0.60, 0.56, 0.47), "f4": (0.36, 0.37, 0.33), "trees": (0.26, 0.30, 0.25),
    "navy": (0.20, 0.23, 0.32), "shirt": (0.72, 0.73, 0.76), "seat": (0.30, 0.34, 0.40),
}

# Aircraft (fictional, Dash 8-100 / ATR 42 class): metres, origin = CG on the fuselage axis.
PLANE = {
    "length": 22.25, "span": 25.9, "fus_r": 1.35, "nacelle_y": 4.0, "nacelle_z": 0.85,
    "prop_x": 3.5, "prop_r": 1.98, "gear_down_height": 2.35,  # root height above ground, gear down
    "wing_z": (1.20, 1.55), "nacelle_rear_x": -3.0,
}


def material(name):
    m = bpy.data.materials.get("PRX_" + name)
    if not m:
        m = bpy.data.materials.new("PRX_" + name)
        m.diffuse_color = (*PALETTE[name], 1.0)
        m.roughness = 0.6
    return m


class Part:
    """One mesh object built from primitives (each with its own palette colour)."""

    def __init__(self, name):
        self.name, self.bm, self.mats = name, bmesh.new(), []

    def _mi(self, mat):
        if mat not in self.mats:
            self.mats.append(mat)
        return self.mats.index(mat)

    def _paint(self, verts, mat):
        mi = self._mi(mat)
        for f in {f for v in verts for f in v.link_faces}:
            f.material_index = mi

    def box(self, size, center, mat="grey", rot=None):
        m = Matrix.Translation(center) @ (Euler([math.radians(a) for a in rot]).to_matrix().to_4x4() if rot else Matrix())
        m = m @ Matrix.Diagonal((*size, 1.0))
        r = bmesh.ops.create_cube(self.bm, size=1.0, matrix=m)
        self._paint(r["verts"], mat)
        return self

    def cyl(self, r1, r2, depth, center, axis="Z", mat="grey", segs=16, rot=None):
        """Cone/cylinder centred on `center`, along an axis (X/Y/Z) or a rot (deg)."""
        if rot is None:
            rot = {"X": (0, 90, 0), "Y": (90, 0, 0), "Z": (0, 0, 0), "-X": (0, -90, 0), "-Z": (180, 0, 0)}[axis]
        m = Matrix.Translation(center) @ Euler([math.radians(a) for a in rot]).to_matrix().to_4x4()
        r = bmesh.ops.create_cone(self.bm, cap_ends=True, segments=segs, radius1=r1, radius2=r2, depth=depth, matrix=m)
        self._paint(r["verts"], mat)
        return self

    def seg(self, a, b, r1, r2=None, mat="grey", segs=12):
        """Cylinder from point a to point b (r1 at a, r2 at b)."""
        a, b = Vector(a), Vector(b)
        d = b - a
        q = d.to_track_quat("Z", "Y")
        m = Matrix.Translation((a + b) / 2) @ q.to_matrix().to_4x4()
        r = bmesh.ops.create_cone(self.bm, cap_ends=True, segments=segs, radius1=r1,
                                  radius2=r1 if r2 is None else r2, depth=d.length, matrix=m)
        self._paint(r["verts"], mat)
        return self

    def sphere(self, r, center, scale=(1, 1, 1), mat="grey", segs=12):
        m = Matrix.Translation(center) @ Matrix.Diagonal((*scale, 1.0))
        res = bmesh.ops.create_uvsphere(self.bm, u_segments=segs, v_segments=max(6, segs // 2), radius=r, matrix=m)
        self._paint(res["verts"], mat)
        return self

    def loft_x(self, sections, mat="grey", segs=16, yscale=1.0):
        """Body of revolution along X: sections = [(x, radius, z_centre)]."""
        rings = []
        for x, r, zc in sections:
            ring = [self.bm.verts.new((x, yscale * r * math.cos(2 * math.pi * i / segs), zc + r * math.sin(2 * math.pi * i / segs)))
                    for i in range(segs)]
            rings.append(ring)
        faces = []
        for a, b in zip(rings, rings[1:]):
            for i in range(segs):
                j = (i + 1) % segs
                faces.append(self.bm.faces.new((a[i], a[j], b[j], b[i])))
        faces.append(self.bm.faces.new(list(reversed(rings[0]))))
        faces.append(self.bm.faces.new(rings[-1]))
        mi = self._mi(mat)
        for f in faces:
            f.material_index = mi
        return self

    def slab(self, outline, thickness, axis="Z", offset=0.0, mat="grey"):
        """Flat polygon extruded along an axis. outline = 2D points in the plane
        normal to `axis` ((x,y) for Z, (x,z) for Y), centred on `offset`."""
        def p3(u, v, w):
            return {"Z": (u, v, w), "Y": (u, w, v)}[axis]
        lo = [self.bm.verts.new(p3(u, v, offset - thickness / 2)) for u, v in outline]
        hi = [self.bm.verts.new(p3(u, v, offset + thickness / 2)) for u, v in outline]
        faces = [self.bm.faces.new(lo), self.bm.faces.new(list(reversed(hi)))]
        n = len(outline)
        for i in range(n):
            j = (i + 1) % n
            faces.append(self.bm.faces.new((lo[i], lo[j], hi[j], hi[i])))
        mi = self._mi(mat)
        for f in faces:
            f.material_index = mi
        bmesh.ops.recalc_face_normals(self.bm, faces=faces)
        return self

    def finish(self, coll, parent=None, loc=(0, 0, 0), rot=None, hidden=False, mesh=None):
        if mesh is None:
            mesh = bpy.data.meshes.new(self.name)
            bmesh.ops.recalc_face_normals(self.bm, faces=self.bm.faces[:])
            self.bm.to_mesh(mesh)
            for m in self.mats:
                mesh.materials.append(material(m))
        self.bm.free()
        ob = bpy.data.objects.new(self.name, mesh)
        coll.objects.link(ob)
        if parent:
            ob.parent = parent  # identity parent inverse: loc is in the parent's space
        ob.location = loc
        if rot:
            ob.rotation_euler = [math.radians(a) for a in rot]
        if hidden:
            ob.hide_viewport = ob.hide_render = True
        return ob


def empty(name, coll, parent=None, loc=(0, 0, 0), size=1.0):
    ob = bpy.data.objects.new(name, None)
    ob.empty_display_type, ob.empty_display_size = "PLAIN_AXES", size
    coll.objects.link(ob)
    if parent:
        ob.parent = parent
    ob.location = loc
    return ob


def copy_obj(name, src, coll, parent=None, loc=(0, 0, 0), rot=(0, 0, 0)):
    """Linked duplicate (shares the mesh): cheap crowds of seats/people."""
    ob = bpy.data.objects.new(name, getattr(src, "data", src))
    coll.objects.link(ob)
    if parent:
        ob.parent = parent
    ob.location, ob.rotation_euler = loc, [math.radians(a) for a in rot]
    return ob


def new_collection(name):
    c = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(c)
    return c


# ---------------------------------------------------------------- aircraft

def build_turboprop(coll, code, cfg):
    P = PLANE
    root = empty(f"{code}_root", coll, size=3)
    root["sg_proxy"] = "turboprop"
    for k in ("length", "span", "gear_down_height"):
        root[k] = P[k]
    r = P["fus_r"]
    # fuselage: body of revolution, tail cone sweeps up, nose slightly down
    Part(f"{code}_fuselage").loft_x([
        (-12.3, 0.22, 0.85), (-11.0, 0.45, 0.70), (-8.5, 0.90, 0.38), (-6.0, 1.25, 0.08), (-4.5, r, 0.0),
        (5.5, r, 0.0), (7.2, 1.22, -0.08), (8.6, 0.95, -0.22), (9.5, 0.55, -0.34), (9.95, 0.12, -0.40),
    ], mat="light").finish(coll, root)
    # windows (11 per side), cockpit glazing, slate cheatline + spine stripe
    win = Part(f"{code}_windows")
    for i in range(11):
        x = 4.55 - i * 0.78 + 0.08
        for s in (1, -1):
            win.box((0.24, 0.05, 0.30), (x, s * (r - 0.01), 0.19), "dark")
    for s in (1, -1):
        win.box((0.55, 0.05, 0.34), (8.15, s * 1.05, 0.32), "dark", rot=(0, 0, s * -14))
    win.box((0.30, 1.30, 0.32), (8.62, 0, 0.42), "dark", rot=(0, 52, 0))
    win.finish(coll, root)
    stripe = Part(f"{code}_stripes")
    for s in (1, -1):
        stripe.box((11.5, 0.04, 0.12), (0.4, s * (r + 0.005), -0.12), "slate")
    stripe.box((13.0, 0.28, 0.04), (-0.6, 0, r + 0.01), "slate")
    stripe.finish(coll, root)

    # high straight wing on top (LE root +1.6 / tip +1.3, TE root -1.0 / tip -0.2)
    half = P["span"] / 2
    z0, z1 = P["wing_z"]
    Part(f"{code}_wing").slab([(1.3, -half), (1.6, 0), (1.3, half), (-0.2, half), (-1.0, 0), (-0.2, -half)],
                              z1 - z0, "Z", (z0 + z1) / 2, "grey").finish(coll, root)

    def te_x(y):
        return -1.0 + 0.8 * abs(y) / half

    # flaps (pivot on the hinge line; rot Y negative = down, -30 = landing flap)
    for side, s in (("L", 1), ("R", -1)):
        y_mid = s * 4.6
        hinge = (te_x(y_mid), y_mid, z0 + 0.08)
        f = Part(f"{code}_flap_{side}")
        f.slab([(0, -3.0), (0, 3.0), (-0.6, 3.0), (-0.6, -3.0)], 0.12, "Z", 0.0, "mid")
        f.finish(coll, root, loc=hinge)

    # nacelles under the wing, props (hub + 4 blades + spinning disc), main gear
    ny, nz = P["nacelle_y"], P["nacelle_z"]
    for side, s in (("L", 1), ("R", -1)):
        Part(f"{code}_nacelle_{side}").loft_x([
            (3.25, 0.28, 0.0), (2.8, 0.55, 0.0), (-1.2, 0.55, 0.05), (-3.0, 0.20, 0.15)], "grey", 14
        ).finish(coll, root, loc=(0, s * ny, nz))
        hub = Part(f"{code}_prop_{side}").cyl(0.30, 0.04, 0.7, (0.25, 0, 0), "X", "dark")
        hub = hub.finish(coll, root, loc=(P["prop_x"], s * ny, nz))
        hub.rotation_mode = "XYZ"
        blade_mesh = None
        for i in range(4):
            b = Part(f"{code}_prop_{side}_blade{i + 1}")
            if blade_mesh is None:
                b.box((0.05, 0.26, P["prop_r"] - 0.25), (0, 0, 0.25 + (P["prop_r"] - 0.25) / 2), "dark")
                ob = b.finish(coll, hub)
                blade_mesh = ob.data
            else:
                ob = b.finish(coll, hub, mesh=blade_mesh)
            # ZYX: pitch about the blade's own axis first, then placed around the hub.
            # Pitch 20 = stopped/flat-ish, 88 = feathered (edge-on to the airflow).
            ob.rotation_mode = "ZYX"
            ob.rotation_euler = (math.radians(45 + 90 * i), 0, math.radians(20))
        Part(f"{code}_propdisc_{side}").cyl(P["prop_r"], P["prop_r"], 0.03, (0, 0, 0), "X", "mid", 32
                                            ).finish(coll, root, loc=(P["prop_x"] + 0.05, s * ny, nz), hidden=True)
        # main gear: pivot at the hinge in the nacelle; rot Y +90 = retracted aft into the nacelle.
        # Down: wheel bottoms sit gear_down_height below the root (= on the ground).
        hz = nz - 0.1  # retracted wheels then sit on the nacelle axis (inside the nacelle)
        wz = -P["gear_down_height"] + 0.45 - hz  # wheel centre, in hinge space
        g = Part(f"{code}_gear_{side}")
        g.seg((0, 0, 0), (-0.1, 0, wz), 0.09, mat="mid")
        for wy in (-0.28, 0.28):
            g.cyl(0.45, 0.45, 0.24, (-0.1, wy, wz), "Y", "dark", 16)
        g.finish(coll, root, loc=(1.0, s * ny, hz))
    # nose gear (rot Y -90 = retracted forward)
    ng = Part(f"{code}_gear_N")
    ng.seg((0, 0, 0), (0, 0, -1.0), 0.07, mat="mid")
    ng.cyl(0.35, 0.35, 0.22, (0, 0, -1.0), "Y", "dark", 14)
    ng.finish(coll, root, loc=(7.7, 0, -1.0))
    # T-tail: fin + tailplane on top
    Part(f"{code}_fin").slab([(-8.0, 0.9), (-11.9, 0.9), (-12.3, 5.1), (-10.7, 5.1)], 0.30, "Y", 0.0, "light"
                             ).finish(coll, root)
    Part(f"{code}_tailplane").slab([(-10.6, -3.95), (-10.4, 0), (-10.6, 3.95), (-11.6, 3.95), (-12.2, 0), (-11.6, -3.95)],
                                   0.16, "Z", 5.15, "light").finish(coll, root)
    return f"turboprop {P['length']} m long, {P['span']} m span, high wing, T-tail; parts: props/discs/gear/flaps"


# ---------------------------------------------------------------- people

# Part tree of a 1.745 m figure (scaled to the asked height). pivot = joint in
# the parent's space. Front = +X. A yellow cone on the face shows facing.
FIG = [
    # name, parent, pivot
    ("torso", None, (0, 0, 0.935)),
    ("head", "torso", (0, 0, 0.54)),
    ("arm_L", "torso", (0, 0.21, 0.47)),
    ("arm_R", "torso", (0, -0.21, 0.47)),
    ("thighs", None, (0, 0, 0.935)),
    ("shins", "thighs", (0, 0, -0.46)),
]
POSES = {  # degrees per part, + root lift (m, before scale)
    "stand": {},
    "seated": {"thighs": (0, -90, 0), "shins": (0, 90, 0), "arm_L": (0, -35, 0), "arm_R": (0, -35, 0), "_lift": -0.46},
    "brace": {"thighs": (0, -90, 0), "shins": (0, 90, 0), "torso": (0, 48, 0), "head": (0, 35, 0),
              "arm_L": (0, -165, -8), "arm_R": (0, -165, 8), "_lift": -0.46},
    "walk": {"arm_L": (0, -25, 0), "arm_R": (0, -25, 0), "thighs": (0, -8, 0), "shins": (0, 10, 0)},
}


def fig_prims(part, name, look):
    """Primitives for one figure part (in that part's pivot space)."""
    body, shirt = look.get("body", "navy"), look.get("top", "shirt")
    if name == "torso":
        part.cyl(0.155, 0.17, 0.50, (0, 0, 0.25), "Z", shirt, 14)
        part.sphere(0.16, (0, 0, 0.47), (0.8, 1.25, 0.45), shirt)
        part.sphere(0.15, (0, 0, 0.02), (0.85, 1.2, 0.5), body)
        if look.get("blanket"):
            part.cyl(0.30, 0.20, 0.8, (0, 0, 0.15), "Z", "mid", 14)
    elif name == "head":
        part.cyl(0.05, 0.05, 0.10, (0, 0, 0.04), "Z", "grey", 10)
        part.sphere(0.105, (0, 0, 0.17), (1.0, 0.9, 1.1), "grey")
        part.cyl(0.03, 0.0, 0.07, (0.12, 0, 0.17), "X", "marker", 8)  # nose = facing
        if look.get("bun"):
            part.sphere(0.055, (-0.11, 0, 0.16), mat="dark")
        if look.get("bob"):
            part.sphere(0.12, (-0.02, 0, 0.19), (0.95, 1.0, 0.9), "light")
        if look.get("headset"):
            part.box((0.04, 0.24, 0.03), (0, 0, 0.29), "dark")
            for s in (1, -1):
                part.sphere(0.04, (0, s * 0.105, 0.17), (1, 0.5, 1), "dark")
            part.seg((0, -0.11, 0.15), (0.11, -0.04, 0.10), 0.008, mat="dark")
    elif name in ("arm_L", "arm_R"):
        part.cyl(0.047, 0.04, 0.60, (0, 0, -0.30), "Z", shirt, 10)
        part.sphere(0.05, (0, 0, -0.63), mat="grey")
    elif name == "thighs":
        for s in (1, -1):
            part.cyl(0.08, 0.065, 0.46, (0, s * 0.095, -0.23), "Z", body, 10)
    elif name == "shins":
        for s in (1, -1):
            part.cyl(0.062, 0.05, 0.42, (0, s * 0.095, -0.21), "Z", body, 10)
            part.box((0.25, 0.10, 0.07), (0.06, s * 0.095, -0.44), "dark")


def build_figure(coll, code, cfg):
    """Separate-part figure (head, torso, arms, thighs, shins) a shot can pose."""
    s = cfg.get("height", 1.78) / 1.745
    look = cfg.get("look", {})
    root = empty(f"{code}_root", coll, size=0.5)
    root["sg_proxy"], root["height"] = "figure", cfg.get("height", 1.78)
    root.scale = (s, s, s)
    objs = {}
    for name, parent, pivot in FIG:
        p = Part(f"{code}_{name}")
        fig_prims(p, name, look)
        objs[name] = p.finish(coll, objs[parent] if parent else root, loc=pivot)
    return f"figure {cfg.get('height', 1.78)} m, parts head/torso/arm_L/arm_R/thighs/shins, poses via rotation"


def figure_mesh(name, pose, look, height=1.75):
    """One merged mesh of a posed figure (for crowds). Root at the feet/seat floor."""
    s = height / 1.745
    pz = POSES[pose]
    world = {}
    part = Part(name)
    for pname, parent, pivot in FIG:
        rot = pz.get(pname, (0, 0, 0))
        local = Matrix.Translation(pivot) @ Euler([math.radians(a) for a in rot]).to_matrix().to_4x4()
        world[pname] = (world[parent] if parent else Matrix.Translation((0, 0, pz.get("_lift", 0)))) @ local
        sub = Part("_sub")
        fig_prims(sub, pname, look)
        bmesh.ops.transform(sub.bm, matrix=Matrix.Diagonal((s, s, s, 1)) @ world[pname], verts=sub.bm.verts[:])
        # move faces into the merged part, keeping colours
        remap = [part._mi(m) for m in sub.mats]
        vmap = {v: part.bm.verts.new(v.co) for v in sub.bm.verts}
        for f in sub.bm.faces:
            nf = part.bm.faces.new([vmap[v] for v in f.verts])
            nf.material_index = remap[f.material_index]
        sub.bm.free()
    return part


def build_passengers(coll, code, cfg):
    """Seated cabin load in aircraft coordinates (+ brace and walking sets)."""
    proj = coll.name[: -len(code) - 1]
    root = empty(f"{code}_root", coll, size=0.5)
    root["sg_proxy"] = "passengers"
    looks = [{"body": "navy", "top": "shirt"}, {"body": "mid", "top": "light"}, {"body": "dark", "top": "grey"},
             {"body": "slate", "top": "white"}]
    seats = cabin_seats()
    rnd = random.Random(418)
    # 28 of 34 filled; the aisle seat next to the S07 window passenger stays empty (camera spot)
    empty_seats = {WINDOW_SEAT_KEEP[0] - 1} | set(rnd.sample(
        [i for i in range(len(seats)) if i not in WINDOW_SEAT_KEEP and i != WINDOW_SEAT_KEEP[0] - 1], 5))
    meshes = {}
    for pose, cname in (("seated", coll), ("brace", None)):
        c = cname or new_collection(f"{proj}_{code}_brace")
        r = root if cname else empty(f"{code}_brace_root", c, size=0.5)
        for i, (x, y) in enumerate(seats):
            if i in empty_seats:
                continue
            look, key = looks[i % len(looks)], (pose, i % len(looks))
            if i == WINDOW_SEAT_KEEP[0]:
                look, key = {"body": "slate", "top": "light", "bob": True}, (pose, "woman")  # S07: 60s woman, grey bob
            if key not in meshes:
                p = figure_mesh(f"{code}_{pose}_mesh{len(meshes)}", pose, look, 1.70)
                meshes[key] = p.finish(c, r, loc=(x + 0.02, y, CABIN["floor"]))
                meshes[key].name = f"{code}_{pose}_{i:02d}"
            else:
                copy_obj(f"{code}_{pose}_{i:02d}", meshes[key].data, c, r, (x + 0.02, y, CABIN["floor"]))
    # survivors walking in blankets (local, facing +X)
    c = new_collection(f"{proj}_{code}_walk")
    r = empty(f"{code}_walk_root", c, size=0.5)
    for i, (x, y) in enumerate([(0, 0), (-1.4, 0.9), (-0.8, -1.1), (-2.6, 0.3)]):
        p = figure_mesh(f"{code}_walk_{i}", "walk", {"body": "dark", "top": "mid", "blanket": True}, 1.68 + 0.04 * i)
        p.finish(c, r, loc=(x, y, 0))
    return f"{len(seats) - len(empty_seats)} seated (of {len(seats)} seats) + brace set + 4 walking"


# ---------------------------------------------------------------- interiors (aircraft coordinates)

CABIN = {"floor": -0.95, "ceiling": 0.90, "wall_y": 1.18, "fwd_x": 5.6, "aft_x": -4.8,
         "row1_x": 4.6, "pitch": 0.78, "rows": 11, "single_y": 0.86, "pair_y": (-0.30, -0.78),
         "win_z": (0.0, 0.38)}
WINDOW_SEAT_KEEP = [2 * 3 + 2]  # row 3 right window seat (index order: per row L, pair aisle, pair window)


def cabin_seats():
    """(x, y) of the 34 seats: 11 rows of 1 (left/port) + 2 (right/starboard), row 12 single."""
    C = CABIN
    out = []
    for r in range(C["rows"]):
        x = C["row1_x"] - r * C["pitch"]
        out += [(x, C["single_y"]), (x, C["pair_y"][0]), (x, C["pair_y"][1])]
    out.append((C["row1_x"] - C["rows"] * C["pitch"], C["single_y"]))
    return out


def build_cabin(coll, code, cfg):
    C = CABIN
    root = empty(f"{code}_root", coll, size=0.5)
    root["sg_proxy"] = "cabin"
    f, c, wy = C["floor"], C["ceiling"], C["wall_y"]
    L = C["fwd_x"] - C["aft_x"]
    xm = (C["fwd_x"] + C["aft_x"]) / 2
    Part(f"{code}_floor").box((L, 2 * wy, 0.05), (xm, 0, f - 0.025), "mid").finish(coll, root)
    Part(f"{code}_ceiling").box((L, 2 * wy, 0.05), (xm, 0, c + 0.025), "light").finish(coll, root)
    w0, w1 = C["win_z"]
    walls = Part(f"{code}_walls")
    for s in (1, -1):
        y = s * (wy + 0.03)
        walls.box((L, 0.06, w0 - f), (xm, y, (f + w0) / 2), "light")
        walls.box((L, 0.06, c - w1), (xm, y, (w1 + c) / 2), "light")
        # pillars between the window openings (one window per row)
        xs = [C["row1_x"] - r * C["pitch"] + 0.08 for r in range(C["rows"])]
        edges = [C["fwd_x"]] + [e for x in xs for e in (x + 0.15, x - 0.15)] + [C["aft_x"]]
        for a, b in zip(edges[0::2], edges[1::2]):
            walls.box((a - b, 0.06, w1 - w0), ((a + b) / 2, y, (w0 + w1) / 2), "light")
        walls.box((L, 0.36, 0.28), (xm, s * (wy - 0.18), c - 0.18), "grey")  # overhead bins
    walls.finish(coll, root)
    Part(f"{code}_fwd_wall").box((0.06, 2 * wy, c - f), (C["fwd_x"] + 0.03, 0, (f + c) / 2), "grey") \
        .box((0.03, 0.62, 1.75), (C["fwd_x"] - 0.005, -0.1, f + 0.9), "mid").finish(coll, root)
    Part(f"{code}_aft_wall").box((0.06, 2 * wy, c - f), (C["aft_x"] - 0.03, 0, (f + c) / 2), "grey").finish(coll, root)
    seat = None
    for i, (x, y) in enumerate(cabin_seats()):
        if seat is None:
            p = Part(f"{code}_seat_00")
            p.box((0.46, 0.46, 0.12), (0.0, 0, f + 0.42), "seat")
            p.box((0.10, 0.46, 0.64), (-0.25, 0, f + 0.76), "seat")  # back top 1.08 m: heads show above
            p.box((0.11, 0.30, 0.08), (-0.25, 0, f + 1.10), "light")
            seat = p.finish(coll, root, loc=(x, y, 0))
        else:
            copy_obj(f"{code}_seat_{i:02d}", seat.data, coll, root, (x, y, 0))
    # forward jump seat for the flight attendant (faces aft), in the aisle
    Part(f"{code}_jumpseat").box((0.40, 0.42, 0.08), (-0.25, 0, f + 0.45), "seat") \
        .box((0.06, 0.42, 0.65), (0.0, 0, f + 0.80), "seat").finish(coll, root, loc=(C["fwd_x"] - 0.05, 0.28, 0))
    return f"cabin {L:.1f} m, 34 seats 2+1 (pairs starboard), floor-ceiling {c - f:.2f} m, 11 window openings per side"


COCKPIT = {"floor": -0.90, "seat_x": 7.15, "seat_back_x": 6.55, "seat_y": 0.5, "glare_x": 7.95, "glare_z": 0.02,
           "back_x": 5.8, "wall_y": 0.95, "top": 0.72}


def build_cockpit(coll, code, cfg):
    K = COCKPIT
    root = empty(f"{code}_root", coll, size=0.5)
    root["sg_proxy"] = "cockpit"
    f, wy, top = K["floor"], K["wall_y"], K["top"]
    Part(f"{code}_floor").box((2.8, 2 * wy, 0.05), (7.2, 0, f - 0.025), "mid").finish(coll, root)
    for side, s in (("L", 1), ("R", -1)):
        p = Part(f"{code}_seat_{side}")
        p.box((0.50, 0.50, 0.12), (0.05, 0, f + 0.45), "seat")
        p.box((0.12, 0.50, 0.55), (-0.25, 0, f + 0.78), "seat")  # back top 1.05 m: shoulders/heads show above
        p.box((0.10, 0.26, 0.16), (-0.25, 0, f + 1.13), "seat")
        p.finish(coll, root, loc=(K["seat_x"], s * K["seat_y"], 0))
    gx, gz = K["glare_x"], K["glare_z"]
    panel = Part(f"{code}_panel")
    panel.box((0.30, 1.7, gz - f), (gx + 0.15, 0, (f + gz) / 2), "dark")  # instrument panel
    panel.box((0.55, 1.75, 0.07), (gx + 0.05, 0, gz - 0.035), "dark")  # glareshield
    panel.box((0.85, 0.32, 0.45), (gx - 0.55, 0, f + 0.22), "mid")  # pedestal
    panel.box((0.02, 0.9, 0.06), (gx - 0.19, 0, gz - 0.08), "red")  # master-warning strip (red pulse guide)
    panel.finish(coll, root)
    # two generic red fire T-handles on the glareshield centre (right one = right engine)
    for side, s in (("L", 1), ("R", -1)):
        h = Part(f"{code}_handle_{side}")
        h.cyl(0.012, 0.012, 0.06, (0, 0, 0.03), "Z", "red", 8)
        h.box((0.035, 0.075, 0.025), (0, 0, 0.07), "red")
        h.finish(coll, root, loc=(gx - 0.12, s * 0.08, gz))
    frame = Part(f"{code}_frame")
    frame.box((0.12, 1.9, 0.08), (gx + 0.0, 0, 0.66), "grey")  # header
    for y in (0.0, 0.9, -0.9):
        frame.box((0.07, 0.07, 0.62), (gx + 0.22, y, 0.34), "grey", rot=(0, -25, 0))
    for s in (1, -1):
        y = s * (wy + 0.03)
        frame.box((2.5, 0.06, gz - f + 0.0), (7.05, y, (f + gz) / 2), "light")  # side wall below the window
        frame.box((2.5, 0.06, top - 0.5), (7.05, y, (0.5 + top) / 2), "light")  # above the window
        frame.box((1.2, 0.06, 0.48), (6.4, y, 0.26), "light")  # aft pillar
    frame.box((2.5, 2 * wy, 0.06), (7.05, 0, top + 0.03), "light")  # ceiling
    frame.box((0.9, 0.8, 0.12), (7.35, 0, top - 0.06), "dark")  # overhead panel
    frame.finish(coll, root)
    Part(f"{code}_backwall").box((0.05, 2 * wy, top - f), (K["back_x"], 0, (f + top) / 2), "grey") \
        .finish(coll, root)
    if cfg.get("screens"):  # v002 (2026-10-27, SH080 note): displays + master warning lights so inserts read as a cockpit
        sc = Part(f"{code}_screens")
        for y in (0.62, 0.30, 0.0, -0.30, -0.62):  # PFD / MFD each side + centre engine display, on the panel face
            sc.box((0.02, 0.26, 0.30), (gx - 0.005, y, -0.30), "dark")  # bezel
            sc.box((0.01, 0.22, 0.25), (gx - 0.017, y, -0.30), "blue")  # lit face
        sc.finish(coll, root)
        mw = Part(f"{code}_master_warning")
        for s in (1, -1):  # in front of each pilot on the glareshield's aft edge: red warning + amber caution
            mw.box((0.05, 0.07, 0.03), (gx - 0.20, s * 0.40, gz + 0.015), "red")
            mw.box((0.05, 0.07, 0.03), (gx - 0.20, s * 0.30, gz + 0.015), "marker")
        mw.finish(coll, root)
        return ("cockpit 2.6 m, 2 seats (captain +Y/left, F/O -Y/right), fire T-handles, 5 displays, master warning/caution "
                "lights, windshield frame, hideable back wall")
    return "cockpit 2.6 m, 2 seats (captain +Y/left, F/O -Y/right), fire T-handles, windshield frame, hideable back wall"


# ---------------------------------------------------------------- ground sets

def build_ramp(coll, code, cfg):
    root = empty(f"{code}_root", coll, size=3)
    root["sg_proxy"] = "ramp"
    Part(f"{code}_apron").box((220, 150, 0.1), (10, 0, -0.05), "concrete").finish(coll, root)
    m = Part(f"{code}_markings")
    m.box((90, 0.2, 0.02), (-20, 0, 0.01), "paint")  # lead-in line under the nose wheel
    m.box((0.4, 6, 0.02), (12.5, 0, 0.01), "paint")  # stop bar
    for x in (-25, 22):
        m.box((0.25, 36, 0.02), (x, 0, 0.012), "white")  # stand box
    for y in (-18, 18):
        m.box((47, 0.25, 0.02), (-1.5, y, 0.012), "white")
    m.box((200, 0.3, 0.02), (10, 45, 0.012), "paint")  # taxi line far side
    m.finish(coll, root)
    t = Part(f"{code}_terminal")
    t.box((45, 16, 8), (75, 62, 4), "grey").box((45, 0.2, 2.4), (75, 53.9, 3.2), "dark")
    for x, y in ((45, 48), (95, 40)):
        t.cyl(0.25, 0.18, 16, (x, y, 8), "Z", "mid", 8).box((1.6, 0.6, 0.4), (x, y, 16.2), "light")
    t.finish(coll, root)
    return "apron 220x150 m, lead-in + stand markings, terminal + 2 light poles beyond the nose (port side, +Y)"


def build_farmland(coll, code, cfg):
    size, rnd = cfg.get("size", 20000.0), random.Random(7)
    root = empty(f"{code}_root", coll, size=50)
    root["sg_proxy"] = "farmland"
    xs, ys = [-size / 2], [-size / 2]
    while xs[-1] < size / 2:
        xs.append(min(size / 2, xs[-1] + rnd.uniform(160, 420)))
    while ys[-1] < size / 2:
        ys.append(min(size / 2, ys[-1] + rnd.uniform(140, 380)))
    p = Part(f"{code}_fields")
    tones = ["f1", "f2", "f3", "f4"]
    for i in range(len(xs) - 1):
        for j in range(len(ys) - 1):
            mi = p._mi(rnd.choice(tones))
            v = [p.bm.verts.new((x, y, 0)) for x, y in ((xs[i], ys[j]), (xs[i + 1], ys[j]), (xs[i + 1], ys[j + 1]), (xs[i], ys[j + 1]))]
            p.bm.faces.new(v).material_index = mi
    p.finish(coll, root)
    tr = Part(f"{code}_treelines")
    for x in xs[1:-1]:
        if rnd.random() < 0.35:
            a = rnd.uniform(-size / 2, size / 3)
            tr.box((8, rnd.uniform(300, 1500), 9), (x, a + 400, 4.5), "trees")
    for y in ys[1:-1]:
        if rnd.random() < 0.3:
            a = rnd.uniform(-size / 2, size / 3)
            tr.box((rnd.uniform(300, 1500), 8, 9), (a + 400, y, 4.5), "trees")
    tr.finish(coll, root)
    return f"patchwork {size / 1000:.0f} x {size / 1000:.0f} km, {(len(xs) - 1) * (len(ys) - 1)} fields + tree lines"


def blob(part, R, center, sx=1.0, seed=0, z=0.0, mat="water", n=48):
    rnd = random.Random(seed)
    ph = [rnd.uniform(0, 6.3) for _ in range(3)]
    pts = []
    for i in range(n):
        a = 2 * math.pi * i / n
        r = R * (1 + 0.22 * math.sin(2 * a + ph[0]) + 0.12 * math.sin(3 * a + ph[1]) + 0.07 * math.sin(5 * a + ph[2]))
        pts.append((center[0] + sx * r * math.cos(a), center[1] + r * math.sin(a)))
    part.slab(pts, 0.2, "Z", z, mat)


def build_lake(coll, code, cfg):
    root = empty(f"{code}_root", coll, size=50)
    root["sg_proxy"] = "lake"
    p = Part(f"{code}_water")
    blob(p, 330, (0, 0), 1.7, seed=3, z=0.4)  # Lake Tarrow (~1.1 x 0.66 km)
    blob(p, 95, (-1100, -620), 1.3, seed=5, z=0.4)  # small second lake
    p.finish(coll, root)
    return "Lake Tarrow ~1.1 x 0.66 km + small lake at (-1100, -620)"


def build_field(coll, code, cfg):
    proj = coll.name[: -len(code) - 1]
    L, W, rnd = 2000.0, 420.0, random.Random(11)
    root = empty(f"{code}_root", coll, size=20)
    root["sg_proxy"] = "field"
    Part(f"{code}_stubble").box((L, W, 0.2), (0, 0, 0.0), "stubble").finish(coll, root)
    t = Part(f"{code}_tufts")
    for _ in range(6000):
        x, y = rnd.uniform(-700, 700), rnd.uniform(-190, 160)
        t.box((0.5, 0.5, rnd.uniform(0.2, 0.45)), (x, y, 0.2), "f3")
    t.finish(coll, root)
    Part(f"{code}_treeline").box((L, 10, 14), (0, W / 2 + 8, 7), "trees").box((L, 8, 10), (0, -W / 2 - 6, 5), "trees") \
        .finish(coll, root)
    # skid/rut track for after the landing: own collection so only S19-type shots instance it
    c = new_collection(f"{proj}_{code}_skidtrack")
    r2 = empty(f"{code}_skidtrack_root", c, size=5)
    s = Part(f"{code}_skidtrack")
    for y, w in ((4.0, 1.6), (-4.0, 1.6), (0, 1.0)):
        s.box((520, w, 0.06), (-260, y, 0.14), "light")
    s.box((520, 14, 0.04), (-260, 0, 0.12), "grey")
    s.finish(c, r2)
    return f"stubble field {L / 1000:.1f} km x {W:.0f} m along X, tufts for ground speed, tree lines; + skidtrack set (520 m behind the origin)"


# ---------------------------------------------------------------- fx + vehicles

def build_fire_smoke(coll, code, cfg):
    root = empty(f"{code}_root", coll, size=1)
    root["sg_proxy"] = "fire_smoke"
    Part(f"{code}_flame").cyl(0.55, 0.05, 2.6, (-1.3, 0, 0), "-X", "fire", 12).finish(coll, root)
    tr = Part(f"{code}_trail")
    for i in range(5):
        tr.cyl(0.3 + i * 0.45, 0.3 + (i + 1) * 0.45, 12, (-0.5 - 6 - i * 12, 0, 0.1 * i), "-X", "smoke", 14)
    tr.finish(coll, root)
    Part(f"{code}_puff").sphere(1.6, (0, 0, 0), (1.3, 1, 1), "puff", 14).finish(coll, root, hidden=True)
    Part(f"{code}_wisp").cyl(0.15, 0.7, 7, (0, 0, 3.5), "Z", "smoke", 12).finish(coll, root, hidden=True)
    return "flame cone + 60 m smoke trail along -X (aft); puff + wisp hidden by default"


def build_vehicles(coll, code, cfg):
    root = empty(f"{code}_root", coll, size=2)
    root["sg_proxy"] = "emergency_vehicles"
    for i, (name, size, loc, rot) in enumerate([
            ("truck", (9.5, 2.5, 3.0), (0, 0), 0), ("unit_a", (5.0, 2.0, 1.8), (-13, 6), 35), ("unit_b", (5.2, 2.0, 2.4), (11, 7), -25)]):
        p = Part(f"{code}_{name}")
        L, W, H = size
        p.box((L, W, H - 0.5), (0, 0, 0.5 + (H - 0.5) / 2), "light" if i else "mid")
        for x in (L * 0.35, -L * 0.35):
            for y in (W / 2, -W / 2):
                p.cyl(0.42, 0.42, 0.3, (x, y, 0.42), "Y", "dark", 12)
        p.box((0.35, W * 0.42, 0.18), (L * 0.2, W * 0.22, H + 0.09), "red")
        p.box((0.35, W * 0.42, 0.18), (L * 0.2, -W * 0.22, H + 0.09), "blue")
        p.finish(coll, root, loc=(*loc, 0), rot=(0, 0, rot))
    return "fire truck + 2 units with red/blue light bars"


KINDS = {"turboprop": build_turboprop, "figure": build_figure, "passengers": build_passengers,
         "cockpit": build_cockpit, "cabin": build_cabin, "ramp": build_ramp, "farmland": build_farmland,
         "lake": build_lake, "field": build_field, "fire_smoke": build_fire_smoke, "vehicles": build_vehicles}


def build(coll, code, cfg):
    """Build proxy `cfg['kind']` into `coll`; returns a one-line description."""
    return KINDS[cfg["kind"]](coll, code, cfg)
