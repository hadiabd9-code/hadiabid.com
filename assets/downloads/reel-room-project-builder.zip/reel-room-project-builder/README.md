# Reel Room project builder

Turns a project's shot list and asset list into a folder tree and one Blender layout
file per shot (scene, frame range, fps, resolution, camera, and the shot's assets
LINKED from their newest asset file). Part of Reel Room, my shot review tool:
https://hadiabid.com/lab/reel-room/

- Python 3.11+ (stdlib only). Blender 4.x/5.x for the .blend step.
- Nothing is ever overwritten: an existing shot file is skipped, or with
  `--new-version` the next `_v###` is made.

## Files
- `project_builder.py`  the builder (dry run by default)
- `blender_build.py`    runs inside Blender, called by the builder
- `blender_proxies.py`  grey block-in proxy assets (used by blender_build.py)
- `blender_verify.py`   optional check of the built files (PASS/FAIL per shot)
- `templates/generic.json`  folder layout + file naming
- `specs/example.json`  a 3-shot example project

## Run it
Edit `specs/example.json`: set `"root"` to the folder the project should live in
(e.g. `<PROJECT_ROOT>` -> `D:/projects/NightShift`), or pass `--root`.

```bash
# 1. dry run: prints the folder tree and the shot files it would make, creates nothing
python project_builder.py --spec specs/example.json --root <PROJECT_ROOT>

# 2. apply: folders only
python project_builder.py --spec specs/example.json --root <PROJECT_ROOT> --apply

# 3. apply + Blender: placeholder asset files + one layout .blend per shot
python project_builder.py --spec specs/example.json --root <PROJECT_ROOT> --apply --blender --stub-assets \
    --blender-exe "<BLENDER_EXE>"

# 4. optional check of what was built
"<BLENDER_EXE>" -b --factory-startup --python blender_verify.py -- build/jobs/job_ns_<stamp>.json
```

Useful flags: `--only SH010,SH020`, `--new-version`, `--stub-assets`, `--seed`
(write `build/seed_<pid>.json` for the review page and stop). Set the `BLENDER_EXE`
environment variable instead of passing `--blender-exe` every time.

Outputs go next to the script in `build/`: `build_report_<pid>.json`,
`update_<pid>.json` (shot build status + asset files, for the review page) and
`jobs/` (Blender job + log).

Naming: shots `<PROJ>_SH###_<stage>_v###`, assets `<PROJ>_<asset>_<stage>_v###.blend`.
Highest `_v###` = latest.

(c) Hadi Abid. Shared as a portfolio sample, as is, no warranty.
