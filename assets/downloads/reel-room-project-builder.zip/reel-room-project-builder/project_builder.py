"""Reel Room project builder: review-page data -> project folders + Blender shot files.

The Reel Room page holds the project, its assets and its shots. The page
cannot touch disk, so this script does the disk side on the studio PC:

  1. folder tree from a template (templates/<name>.json),
  2. optional stub asset .blend files (a placeholder you can link now and
     replace with the real model later),
  3. one layout .blend per shot: scene, frame range, fps, resolution,
     camera, and the shot's assets LINKED from their latest asset file.

Default is a DRY RUN: it prints what it would create and what already exists.
Nothing is ever overwritten: an existing file is skipped (or, with
--new-version, the next _v### is made).

Input (one of):
  --project build/export_<pid>.json   {project:{id,...}, assets:[...], shots:[...]}
                                      (exported from the review page's database;
                                      docs carry `id` + fields)
  --project <dir> --pid <pid>         a folder of exported docs
                                      (files named <collection>__<doc id>.json)
  --spec specs/<name>.json            same shape, written by hand (ids optional,
                                      shots may give `length` instead of out_f)

Examples:
  python project_builder.py --spec specs/example.json --root <PROJECT_ROOT>           # dry run
  python project_builder.py --spec specs/example.json --seed                          # write build/seed_<pid>.json only
  python project_builder.py --spec specs/example.json --root <PROJECT_ROOT> --apply   # folders
  python project_builder.py --spec specs/example.json --root <PROJECT_ROOT> --apply --blender --stub-assets

Layout recipes (optional, 2026-10-26): --layout specs/<pid>_layout.json =
  {"proxies": {asset code: {"kind": ...}},      block-in proxy instead of the stub cube
   "copy": [[src, dst], ...],                    board panels / sound copied into the
                                                 project root (never overwritten) so
                                                 the shot files can use relative paths
   "shots": {code: {"in_f", "out_f",             timing from the board (overrides the grid)
                    "extra_assets": [...],       assets the layout needs on top of the grid's
                    "layout": {...}}}}           recipe run by blender_build.apply_layout()
  First used for a 20-shot layout pass (grey proxies, keyed cameras, board panels).

Outputs (only with --apply): build/build_report_<pid>.json and
build/update_<pid>.json (batch update ops for the review page's database).
Python 3.11+, stdlib only.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUILD = HERE / "build"
DEFAULT_BLENDER = os.environ.get("BLENDER_EXE", "blender")  # or pass --blender-exe
SHOT_STAGES = ["layout", "animation", "lighting", "fx", "comp"]
# Version kinds in pipeline order (upstream -> downstream), same list as PIPELINE in the review page and
# "pipeline" in templates/*.json. Layout is a standard step: every shot has a layout/ folder and the page
# shows an empty "Layout: not yet" tab until a layout version exists. Empty slots are page-side only:
# nothing is written to the db for them.
PIPELINE = ["board", "animatic", "layout", "keyframe", "gen", "render", "comp"]
ASSET_STAGES = ["model", "surfacing", "rig"]
ASSET_TYPES = ["ch", "pr", "bgp", "ext", "int", "fx"]


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def slug(text):
    """'Record disc (s)' -> 'record_disc'. Asset codes are snake_case."""
    t = re.sub(r"\(s\)", "", str(text), flags=re.I)
    t = re.sub(r"[^a-z0-9]+", "_", t.lower())
    return t.strip("_")


# ---------- input ----------

def load_dir(folder, pid):
    """Read a folder of exported docs: <collection>__<doc id>.json files."""
    if not pid:
        sys.exit("--pid is needed when --project is a folder")
    data = {"project": None, "assets": [], "shots": []}
    for f in sorted(Path(folder).glob("*.json")):
        coll, _, doc_id = f.stem.partition("__")
        doc = json.loads(f.read_text(encoding="utf-8"))
        doc = {"id": doc_id, **doc}
        if coll == "projects" and doc_id == pid:
            data["project"] = doc
        elif coll in ("assets", "shots") and doc.get("project") == pid:
            data[coll].append(doc)
    if not data["project"]:
        sys.exit(f"project {pid} not found in {folder}")
    return data


def normalize(data):
    """Fill defaults so export files and hand specs look the same from here on."""
    p = dict(data["project"])
    p["code"] = str(p.get("code") or "").upper()
    if not p["code"]:
        sys.exit("project needs a code, e.g. AP")
    p.setdefault("id", p["code"].lower())  # project id = lower-case code, same as the page
    p.setdefault("fps", 24)
    p.setdefault("res", p.get("frame_size") or [1920, 1080])
    p.setdefault("frame_start", 1)
    p.setdefault("template", "generic")
    p.setdefault("shot_step", 10)
    p.setdefault("stages", SHOT_STAGES)
    pid = p["id"]

    assets = []
    for i, a in enumerate(data.get("assets", [])):
        a = dict(a)
        a.setdefault("code", slug(a["name"]))
        a.setdefault("id", f"{pid}__{a['code']}")
        a.setdefault("name", a["code"])
        a.setdefault("sort", (i + 1) * 10)
        a.setdefault("file", "")
        a.setdefault("stages", {k: "todo" for k in ASSET_STAGES})
        a["project"] = pid
        if a.get("type") not in ASSET_TYPES:
            sys.exit(f"asset {a['code']}: type must be one of {ASSET_TYPES}, got {a.get('type')!r}")
        assets.append(a)
    codes = [a["code"] for a in assets]
    dupes = sorted({c for c in codes if codes.count(c) > 1})
    if dupes:
        sys.exit(f"duplicate asset codes: {dupes}")

    shots, cursor = [], p["frame_start"]
    for s in data.get("shots", []):
        s = dict(s)
        s.setdefault("id", f"{pid}__{s['code']}")
        if "in_f" not in s:
            s["in_f"] = cursor
        if "out_f" not in s:
            s["out_f"] = s["in_f"] + int(s.get("length", 48))
        s.pop("length", None)
        cursor = s["out_f"]  # back to back; out_f is exclusive, same as the page
        num = re.sub(r"\D", "", s["code"])
        s.setdefault("sort", int(num) if num else 0)
        s.setdefault("title", "")
        s.setdefault("assets", [])
        s.setdefault("stages", {k: "todo" for k in p["stages"]})
        s.setdefault("build", {"status": "", "file": "", "at": "", "msg": ""})
        s["project"] = pid
        shots.append(s)
    return p, assets, shots


def merge_layout(shots, lay):
    """Board timing, extra assets and the layout recipe onto the grid's shots."""
    for s in shots:
        L = lay.get("shots", {}).get(s["code"])
        if not L:
            continue
        for k in ("in_f", "out_f"):
            if k in L:
                s[k] = L[k]
        extra = [c for c in L.get("extra_assets", []) if c not in s["assets"]]
        if extra:
            s["assets"] = s["assets"] + extra
            s["_extra_assets"] = extra
        s["_layout"] = L.get("layout")


def copy_media(pairs):
    """Copy board panels / sound into the project (never overwrite)."""
    n = 0
    for src, dst in pairs:
        dst = Path(dst)
        if dst.exists():
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        n += 1
    return n


def load_template(name):
    f = HERE / "templates" / f"{name}.json"
    if not f.exists():
        sys.exit(f"template not found: {f}")
    tpl = json.loads(f.read_text(encoding="utf-8"))
    tpl.setdefault("pipeline", PIPELINE)
    # layout is a standard per-shot step: the shot file lives in layout/, so the folder must be in the template
    if "layout" not in tpl.get("shot_subfolders", []) or "layout" not in tpl["pipeline"]:
        sys.exit(f"template {name}: 'layout' must be in shot_subfolders and pipeline")
    return tpl


# ---------- seed (hand spec -> grid) ----------

def write_seed(p, assets, shots):
    strip = lambda d: {k: v for k, v in d.items() if k != "id"}
    writes = [{"op": "set", "collection": "projects", "doc_id": p["id"], "data": strip(p)}]
    stamp = now()
    for a in assets:
        writes.append({"op": "set", "collection": "assets", "doc_id": a["id"],
                       "data": {**strip(a), "created": a.get("created", stamp)}})
    for s in shots:
        writes.append({"op": "set", "collection": "shots", "doc_id": s["id"],
                       "data": {"thumb": "", **strip(s)}})
    BUILD.mkdir(exist_ok=True)
    out = BUILD / f"seed_{p['id']}.json"
    out.write_text(json.dumps(writes, indent=1), encoding="utf-8")
    print(f"{len(writes)} writes ({len(assets)} assets, {len(shots)} shots) -> {out}")


# ---------- paths + versions ----------

def versions_of(path_pattern):
    """All existing files for a _v{ver} pattern, as {version: Path}."""
    pat = Path(path_pattern)
    rx = re.compile("^" + re.escape(pat.name).replace(r"\{ver\}", r"(\d{3,})") + "$")
    found = {}
    if pat.parent.is_dir():
        for f in pat.parent.iterdir():
            m = rx.match(f.name)
            if m and f.is_file():
                found[int(m.group(1))] = f
    return found


class Planner:
    def __init__(self, p, assets, shots, tpl, root, args):
        self.p, self.assets, self.shots, self.tpl, self.root, self.a = p, assets, shots, tpl, root, args
        self.entries = {}   # rel parts tuple -> (kind, note)
        self.stubs, self.shot_jobs, self.report = [], [], {"shots": {}, "assets": {}}
        self.layout = {}

    def fmt(self, pattern, **kw):
        return pattern.format(proj=self.p["code"], **kw)

    def add(self, path, kind, note=""):
        rel = Path(path).relative_to(self.root).parts
        for i in range(1, len(rel)):  # parents count as folders
            parent = rel[:i]
            if parent not in self.entries:
                self.entries[parent] = ("dir", "exists" if (self.root.joinpath(*parent)).is_dir() else "new")
        if kind == "dir":
            note = "exists" if Path(path).is_dir() else "new"
        self.entries[rel] = (kind, note)

    def asset_dir(self, a):
        t = self.tpl
        return self.root / t["asset_root"] / t["asset_type_dirs"][a["type"]] / a["code"]

    def asset_latest(self, a):
        """Newest file of the first stage (rig > surfacing > model) that has any version."""
        for stage in self.tpl["asset_link_order"]:
            pattern = self.asset_dir(a) / self.fmt(self.tpl["asset_file"], code=a["code"], stage=stage, ver="{ver}")
            vs = versions_of(pattern)
            if vs:
                n = max(vs)
                return vs[n], f"{stage} v{n:03d}"
        for st in self.stubs:  # a stub planned this run counts as the latest
            if st["code"] == a["code"]:
                return Path(st["path"]), "model v001 (stub)"
        return None, ""

    def selected_shots(self):
        only = {c.strip().upper() for c in (self.a.only or "").split(",") if c.strip()}
        out = []
        for s in self.shots:
            if only and s["code"].upper() not in only:
                continue
            if self.a.requested and (s.get("build") or {}).get("status") != "requested":
                continue
            out.append(s)
        return out

    def plan(self):
        t = self.tpl
        for f in t["folders"]:
            self.add(self.root / f, "dir")
        for d in sorted(set(t["asset_type_dirs"].values())):
            self.add(self.root / t["asset_root"] / d, "dir")

        shots = self.selected_shots()
        filtered = bool(self.a.only or self.a.requested)
        used = {c for s in shots for c in s.get("assets", [])}
        by_code = {a["code"]: a for a in self.assets}

        for a in self.assets:
            adir = self.asset_dir(a)
            self.add(adir, "dir")
            for sub in t["asset_subfolders"]:
                self.add(adir / sub, "dir")
            latest, _ = self.asset_latest(a)
            want_stub = self.a.stub_assets and latest is None and (not filtered or a["code"] in used)
            if want_stub:
                path = adir / self.fmt(t["asset_file"], code=a["code"], stage="model", ver="001")
                proxy = (self.layout.get("proxies") or {}).get(a["code"])
                self.stubs.append({"code": a["code"], "path": str(path), "label": a.get("name", a["code"]),
                                   "type": a["type"], "collection": self.fmt(t["asset_collection"], code=a["code"]),
                                   **({"proxy": proxy} if proxy else {})})
                self.add(path, "file", f"new {'proxy ' + proxy['kind'] if proxy else 'stub'}")

        for s in shots:
            sdir = self.root / t["shot_root"] / s["code"]
            self.add(sdir, "dir")
            for sub in t["shot_subfolders"]:
                self.add(sdir / sub, "dir")
            pattern = sdir / self.fmt(t["shot_file"], shot=s["code"], ver="{ver}")
            vs = versions_of(pattern)
            rec = {"code": s["code"], "id": s["id"]}
            if vs and not self.a.new_version:
                n = max(vs)
                rec.update(status="skipped", file=str(vs[n]), msg=f"kept existing v{n:03d} (rebuild = --new-version)")
                self.add(vs[n], "file", "exists, skip")
            else:
                n = max(vs) + 1 if vs else 1
                path = Path(str(pattern).replace("{ver}", f"{n:03d}"))
                links, missing = [], []
                for code in s.get("assets", []):
                    a = by_code.get(code)
                    f, label = self.asset_latest(a) if a else (None, "")
                    if f:
                        links.append({"code": code, "path": str(f), "label": label,
                                      "collection": self.fmt(t["asset_collection"], code=code)})
                    else:
                        missing.append(code if a else f"{code} (not in assets)")
                last = s["out_f"] - 1  # out_f is exclusive (duration = out_f - in_f)
                self.shot_jobs.append({"code": s["code"], "id": s["id"], "path": str(path),
                                       "scene": f"{self.p['code']}_{s['code']}",
                                       "camera": ((s.get("_layout") or {}).get("camera") or {}).get("name") or f"CAM_{s['code']}",
                                       "frame_start": s["in_f"], "frame_end": last,
                                       "links": links, "missing": missing,
                                       **({"layout": s["_layout"]} if s.get("_layout") else {})})
                rec.update(status="planned", file=str(path), msg=("missing assets: " + ", ".join(missing)) if missing else "")
                self.add(path, "file", f"new v{n:03d}")
            self.report["shots"][s["code"]] = rec
        return shots

    def print_tree(self):
        print(f"{self.root}  [{'exists' if self.root.is_dir() else 'new'}]")
        for rel in sorted(self.entries, key=lambda r: [x.lower() for x in r]):
            kind, note = self.entries[rel]
            name = rel[-1] + ("/" if kind == "dir" else "")
            print(f"{'  ' * len(rel)}{name:<{max(1, 46 - 2 * len(rel))}} [{note}]")
        dirs = [v for v in self.entries.values() if v[0] == "dir"]
        new_dirs = sum(1 for v in dirs if v[1] == "new")
        files = [v for v in self.entries.values() if v[0] == "file"]
        print(f"\n{len(dirs)} folders ({len(dirs) - new_dirs} exist, {new_dirs} new), {len(files)} files listed")

    def print_shots(self):
        if not self.report["shots"]:
            print("No shots selected.")
            return
        print("\nShots:")
        jobs = {j["code"]: j for j in self.shot_jobs}
        for code, rec in self.report["shots"].items():
            j = jobs.get(code)
            if not j:
                print(f"  {code}: skip, {rec['msg']}")
                continue
            links = ", ".join(f"{l['code']} ({l['label']})" for l in j["links"]) or "none"
            print(f"  {code}: f{j['frame_start']}-{j['frame_end']} -> {Path(j['path']).name}; links: {links}"
                  + (f"; MISSING: {', '.join(j['missing'])}" if j["missing"] else ""))


# ---------- blender ----------

def run_blender(pl, args):
    exe = Path(shutil.which(args.blender_exe) or args.blender_exe)
    if not exe.exists():
        sys.exit(f"Blender not found: {exe}")
    jobs_dir = BUILD / "jobs"
    jobs_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    job_file = jobs_dir / f"job_{pl.p['id']}_{stamp}.json"
    results = jobs_dir / f"results_{pl.p['id']}_{stamp}.json"
    res = pl.p["res"]
    job = {"results": str(results), "fps": pl.p["fps"], "res": [int(res[0]), int(res[1])],
           "stubs": pl.stubs, "shots": pl.shot_jobs}
    job_file.write_text(json.dumps(job, indent=1), encoding="utf-8")
    log = jobs_dir / f"blender_{pl.p['id']}_{stamp}.log"
    cmd = [str(exe), "-b", "--factory-startup", "--python", str(HERE / "blender_build.py"), "--", str(job_file)]
    print(f"\nBlender: {len(pl.stubs)} stub assets, {len(pl.shot_jobs)} shots (log {log.name})")
    with open(log, "w", encoding="utf-8", errors="replace") as fh:
        proc = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, timeout=1800)
    out = json.loads(results.read_text(encoding="utf-8")) if results.exists() else []
    if proc.returncode != 0 and not out:
        print(f"Blender exited {proc.returncode}, no results. See {log}")
    print(f"job: {job_file}")
    return out, log


# ---------- main ----------

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--project", type=Path, help="export json from the review page (or a folder of exported docs)")
    src.add_argument("--spec", type=Path, help="hand-written spec, same shape as the export")
    ap.add_argument("--pid", help="project id, when --project is a folder")
    ap.add_argument("--seed", action="store_true", help="write build/seed_<pid>.json (review page import) and stop")
    ap.add_argument("--apply", action="store_true", help="create folders (default is a dry run)")
    ap.add_argument("--blender", action="store_true", help="also build .blend files (needs --apply)")
    ap.add_argument("--stub-assets", action="store_true", help="make placeholder asset files for assets with none")
    ap.add_argument("--only", help="shot codes, e.g. SH010,SH020")
    ap.add_argument("--requested", action="store_true", help="only shots with build.status = requested")
    ap.add_argument("--new-version", action="store_true", help="if a shot file exists, make the next _v###")
    ap.add_argument("--root", help="override the project root (testing)")
    ap.add_argument("--layout", type=Path, help="layout recipes json (board timing, proxies, per-shot layout)")
    ap.add_argument("--tag", default="", help="suffix for build_report/update file names (e.g. _layout_v002), so a "
                    "partial rebuild never replaces the full project's report")
    ap.add_argument("--blender-exe", default=DEFAULT_BLENDER)
    a = ap.parse_args()

    if a.spec:
        raw = json.loads(a.spec.read_text(encoding="utf-8"))
    elif a.project.is_dir():
        raw = load_dir(a.project, a.pid)
    else:
        raw = json.loads(a.project.read_text(encoding="utf-8"))
    p, assets, shots = normalize(raw)
    lay = json.loads(a.layout.read_text(encoding="utf-8")) if a.layout else {}
    if lay:
        merge_layout(shots, lay)

    if a.seed:
        write_seed(p, assets, shots)
        return 0
    if a.blender and not a.apply:
        sys.exit("--blender needs --apply")
    root_s = a.root or p.get("root")
    if not root_s or "<" in root_s:
        sys.exit("no root: set project.root in the spec (replace <PROJECT_ROOT>) or pass --root")
    root = Path(root_s)
    tpl = load_template(p["template"])

    pl = Planner(p, assets, shots, tpl, root, a)
    pl.layout = lay
    pl.plan()
    mode = "APPLY" if a.apply else "DRY RUN (nothing created; add --apply)"
    print(f"Project: {p.get('name', p['id'])} ({p['code']})  id {p['id']}  {p['fps']} fps  {p['res'][0]}x{p['res'][1]}")
    print(f"Root: {root}  template: {tpl['name']}  mode: {mode}")
    print(f"Assets: {len(assets)}  shots: {len(shots)} ({len(pl.report['shots'])} selected)\n")
    pl.print_tree()
    pl.print_shots()
    if not a.apply:
        return 0

    for rel, (kind, _) in sorted(pl.entries.items()):
        if kind == "dir":
            root.joinpath(*rel).mkdir(parents=True, exist_ok=True)
    print("\nFolders created.")
    if lay.get("copy"):
        print(f"Media copied into the project: {copy_media(lay['copy'])} new of {len(lay['copy'])}")

    results = []
    if a.blender and (pl.stubs or pl.shot_jobs):
        results, log = run_blender(pl, a)
    by_path = {r["path"]: r for r in results}

    stamp = now()
    updates = []
    for code, rec in pl.report["shots"].items():
        if rec["status"] == "planned":
            r = by_path.get(rec["file"])
            if not a.blender:
                rec.update(status="folders", msg="folders only (no --blender)")
            elif r and r["status"] == "ok":
                rec.update(status="built", msg="; ".join(x for x in [rec["msg"], r.get("msg", "")] if x))
            else:
                rec.update(status="failed", msg=(r or {}).get("msg", "no result from Blender"))
        if rec["status"] in ("built", "failed", "skipped"):
            status = "failed" if rec["status"] == "failed" else "built"
            data = {"build": {"status": status, "file": rec["file"] if status == "built" else "", "at": stamp, "msg": rec["msg"]}}
            sh = next(x for x in shots if x["code"] == code)
            if sh.get("_extra_assets") and status == "built":  # the layout needed more assets than the grid listed
                data["assets"] = sh["assets"]
            updates.append({"op": "update", "collection": "shots", "doc_id": rec["id"], "data": data})
    for st in pl.stubs:
        r = by_path.get(st["path"])
        pl.report["assets"][st["code"]] = {"stub": st["path"], "status": (r or {}).get("status", "not built")}
    for asset in assets:
        f, label = pl.asset_latest(asset)
        f = f if f and f.exists() else None
        rec = pl.report["assets"].setdefault(asset["code"], {})
        rec.update(file=str(f) if f else "", latest=label if f else "")
        if f and str(f) != asset.get("file"):
            updates.append({"op": "update", "collection": "assets", "doc_id": asset["id"], "data": {"file": str(f)}})

    BUILD.mkdir(exist_ok=True)
    # a --root test run must not replace the real project's report; an older report is kept as .bak
    tag = ("_test" if a.root else "") + a.tag
    rep = BUILD / f"build_report_{p['id']}{tag}.json"
    upd = BUILD / f"update_{p['id']}{tag}.json"
    for f in (rep, upd):
        bak = f.with_name(f.name + f".bak-{datetime.now():%Y-%m-%d}")
        if f.exists() and not bak.exists():
            shutil.copy2(f, bak)
    rep.write_text(json.dumps({"project": p["id"], "root": str(root), "at": stamp, **pl.report}, indent=1), encoding="utf-8")
    upd.write_text(json.dumps(updates, indent=1), encoding="utf-8")
    print("\nResult:")
    for code, rec in pl.report["shots"].items():
        print(f"  {code}: {rec['status']}  {rec['file']}" + (f"  ({rec['msg']})" if rec["msg"] else ""))
    print(f"report -> {rep}\nupdates ({len(updates)} ops) -> {upd}")
    return 1 if any(r["status"] == "failed" for r in pl.report["shots"].values()) else 0


if __name__ == "__main__":
    sys.exit(main())
