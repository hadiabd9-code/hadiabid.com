"""Runs inside Blender (called by project_builder.py), never on its own.

  blender -b --factory-startup --python blender_build.py -- <job.json>

Job = {results, fps, res:[w,h], stubs:[...], shots:[...]} (see project_builder.py).
Stubs are written first, so shots built in the same run can link them.
Each item is wrapped on its own: one bad shot does not stop the others.
Results go to job["results"] as [{kind, path, status ok|exists|failed, msg}].

Optional (2026-10-26, Halden 418):
  stub["proxy"] = {"kind": ...}  -> a grey block-in from blender_proxies.py
                                    instead of the placeholder cube.
  shot["layout"] = recipe         -> a real layout instead of side-by-side
                                    instances: placed/keyed assets (library
                                    overrides when parts are keyed), keyed
                                    camera, board panels as camera background
                                    images, sound strip, Workbench look, notes
                                    text block. Recipe format: see apply_layout().
"""
import json
import math
import os
import sys
import traceback

import bmesh
import bpy
from mathutils import Quaternion, Vector

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import blender_proxies  # noqa: E402  (same folder, Blender-side only)


def fresh_file():
    bpy.ops.wm.read_homefile(use_empty=True)
    # no .blend1 backups: we save twice (once to get a path, once at the end)
    bpy.context.preferences.filepaths.save_version = 0


def save(path):
    bpy.ops.wm.save_as_mainfile(filepath=path, relative_remap=True)


def build_proxy(st):
    """Block-in proxy asset (blender_proxies.py): same collection contract as a stub."""
    fresh_file()
    coll = bpy.data.collections.new(st["collection"])
    bpy.context.scene.collection.children.link(coll)
    desc = blender_proxies.build(coll, st["code"], st["proxy"])
    workbench_look(bpy.context.scene)
    txt = bpy.data.texts.new("PROXY_NOTES")
    txt.write(f"{st['collection']}: grey block-in proxy ({st['proxy']['kind']}), metres, Z up, front = +X.\n{desc}\n"
              f"Parts hang under {st['code']}_root. Replace with the real model as _model_v002 "
              f"(same collection name) and the next shot build links it.\n")
    for c in bpy.data.collections:
        try:
            c.asset_mark()
        except Exception:
            pass
    os.makedirs(os.path.dirname(st["path"]), exist_ok=True)
    save(st["path"])
    return "proxy: " + desc


def build_stub(st):
    """Placeholder asset: collection <PROJ>_<code> with a 1 m cube + a name label."""
    if st.get("proxy"):
        return build_proxy(st)
    fresh_file()
    name = st["collection"]
    coll = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(coll)

    me = bpy.data.meshes.new(f"{name}_placeholder")
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bm.to_mesh(me)
    bm.free()
    cube = bpy.data.objects.new(f"{name}_placeholder", me)
    cube.location.z = 0.5
    cube["sg_placeholder"] = True  # so a later check can find leftover stubs
    coll.objects.link(cube)

    font = bpy.data.curves.new(f"{name}_label", "FONT")
    font.body = st["label"]
    font.size = 0.25
    font.align_x = "CENTER"
    label = bpy.data.objects.new(f"{name}_label", font)
    label.location = (0, -0.55, 1.2)
    label.rotation_euler.x = math.pi / 2
    coll.objects.link(label)

    try:
        coll.asset_mark()  # shows up in the Asset Browser too
    except Exception:
        pass
    os.makedirs(os.path.dirname(st["path"]), exist_ok=True)
    save(st["path"])
    return "placeholder cube + label"


def set_fps(scene, fps):
    if float(fps).is_integer():
        scene.render.fps, scene.render.fps_base = int(fps), 1.0
    else:  # 23.976 -> 24 / 1.001 (NTSC rates are exactly n*1000/1001)
        scene.render.fps = round(fps)
        base = round(fps) / fps
        scene.render.fps_base = 1.001 if abs(base - 1.001) < 0.0005 else base


def workbench_look(scene, sun=None, shadows=True):
    """Grey solid look for layout files + previews: cavity + outline on."""
    scene.render.engine = "BLENDER_WORKBENCH"
    sh = scene.display.shading
    sh.light, sh.color_type = "STUDIO", "MATERIAL"
    sh.show_cavity, sh.cavity_type = True, "BOTH"
    sh.show_object_outline = True
    scene.display.render_aa = "8"
    if sun:  # [azimuth deg from +X toward +Y, elevation deg]: Workbench shadow direction
        az, el = (math.radians(a) for a in sun)
        scene.display.light_direction = (math.cos(el) * math.cos(az), math.cos(el) * math.sin(az), math.sin(el))
        sh.show_shadows, sh.shadow_intensity = bool(shadows), 0.35


# ---------- layout recipe (shot["layout"]) ----------
# {
#  "world": [r,g,b], "sun": [az, el], "shadows"?: bool (Workbench sun shadows, default on),
#  "instances": [{"name", "asset": code, "collection"?: name in the asset file,
#                 "override"?: bool (needed to key/hide parts), "root"?: part keyed for the whole asset,
#                 "parent"?: other instance name, "loc", "rot" (deg), "scale", "interp"?: LINEAR|BEZIER|CONSTANT,
#                 "keys"?: [{"f", "loc"?, "rot"?, "scale"?, "hide"?}],
#                 "parts"?: {object name: {"loc"?, "rot"?, "hide"?, "keys"?: [...], "interp"?}}}],
#  "camera": {"lens", "sensor"?, "clip"?: [s, e], "interp"?, "parent"?: instance name, "keys": [{"f", "loc", "aim"? | "rot"?, "roll"?, "lens"?}],
#             "name"?: scene camera object name (default CAM_SHxxx, e.g. CAM_SH030_fix once the director picked it),
#             "track"?: {"target": instance name, "offset"?: [x,y,z] in the target's space}
#                       -> Track To constraint on an aim empty parented to the target: the target stays
#                          framed every frame (only location is keyed; v002, 2026-10-27)},
#  "alt_cameras"?: [{"name", ...same as camera}]  (suggested-fix cameras, not the scene camera)
#  "panels": [{"image": path, "alpha": [[f, a], ...]}]   (CONSTANT steps; drawn in FRONT, alpha ~0.5)
#  "sound": {"file", "frame"},  "card": {"lines": [[text, size], ...]},  "notes": text
# }

def set_interp(kind):
    bpy.context.preferences.edit.keyframe_new_interpolation_type = kind


def force_interp(id_data, kind, prefix=""):
    """Set every key on id_data (fcurves starting with prefix) to kind.
    Needed: in Blender 5.2 headless, keyframe_insert() ignores keyframe_new_interpolation_type, so layout
    v001's "LINEAR" flight paths came out BEZIER (found by blender_verify's v002 check, 2026-10-27)."""
    ad = id_data.animation_data
    if not ad or not ad.action:
        return
    if getattr(ad, "action_slot", None) is not None:
        from bpy_extras.anim_utils import action_get_channelbag_for_slot
        cb = action_get_channelbag_for_slot(ad.action, ad.action_slot)
        fcs = cb.fcurves if cb else []
    else:
        fcs = getattr(ad.action, "fcurves", [])
    for fc in fcs:
        if fc.data_path.startswith(prefix):
            for k in fc.keyframe_points:
                k.interpolation = kind
            fc.update()


def put(ob, d, frame=None):
    """Set (and key, if a frame is given) loc/rot/scale/hide from a recipe dict."""
    if "loc" in d:
        ob.location = d["loc"]
        if frame is not None:
            ob.keyframe_insert("location", frame=frame)
    if "rot" in d:
        ob.rotation_euler = [math.radians(a) for a in d["rot"]]
        if frame is not None:
            ob.keyframe_insert("rotation_euler", frame=frame)
    if "scale" in d:
        sc = d["scale"]
        ob.scale = (sc, sc, sc) if isinstance(sc, (int, float)) else sc
        if frame is not None:
            ob.keyframe_insert("scale", frame=frame)
    if "hide" in d:
        ob.hide_viewport = ob.hide_render = bool(d["hide"])
        if frame is not None:
            ob.keyframe_insert("hide_viewport", frame=frame)
            ob.keyframe_insert("hide_render", frame=frame)


def animate(ob, spec):
    put(ob, {k: v for k, v in spec.items() if k in ("loc", "rot", "scale", "hide")})
    if spec.get("keys"):
        set_interp(spec.get("interp", "BEZIER"))
        for k in spec["keys"]:
            put(ob, k, k["f"])
        set_interp("BEZIER")
        force_interp(ob, spec.get("interp", "BEZIER"))


def find_part(objs, name):
    for o in objs:
        if o.name == name:
            return o
    for o in objs:
        if o.name.split(".")[0] == name:
            return o
    return None


def cam_rot(loc, key, prev):
    if "rot" in key:
        return [math.radians(a) for a in key["rot"]]
    q = (Vector(key["aim"]) - Vector(loc)).to_track_quat("-Z", "Y")
    if key.get("roll"):
        q = q @ Quaternion((0, 0, 1), math.radians(key["roll"]))
    return q.to_euler("XYZ", prev) if prev is not None else q.to_euler("XYZ")


def setup_camera(cam, c, drivers):
    """Lens/filmback (16:9 36 x 20.25 mm) + location/rotation keys (aim = look-at point)."""
    cd = cam.data
    cd.sensor_fit, cd.sensor_width = "HORIZONTAL", c.get("sensor", 36.0)
    cd.sensor_height = cd.sensor_width * 9 / 16
    cd.lens = c.get("lens", 50)
    cd.clip_start, cd.clip_end = c.get("clip", [0.05, 20000])
    if c.get("parent"):  # camera rides with an asset (e.g. inside a banking cockpit): keys are local
        cam.parent = drivers[c["parent"]]
    tr = c.get("track")
    if tr:  # aim empty rides with the target (e.g. the right nacelle): exact framing, no rotation curves
        aim = bpy.data.objects.new(f"{cam.name}_aim", None)
        aim.empty_display_type, aim.empty_display_size = "SPHERE", 0.3
        bpy.context.scene.collection.objects.link(aim)
        aim.parent = drivers[tr["target"]]
        aim.location = tr.get("offset", (0, 0, 0))
        con = cam.constraints.new("TRACK_TO")
        con.target, con.track_axis, con.up_axis = aim, "TRACK_NEGATIVE_Z", "UP_Y"
    set_interp(c.get("interp", "BEZIER"))
    prev = None
    keys = c.get("keys", [])
    for k in keys:
        cam.location = k["loc"]
        if not tr:
            cam.rotation_euler = cam_rot(k["loc"], k, prev)
            prev = cam.rotation_euler.copy()
        if "lens" in k:
            cd.lens = k["lens"]
        if len(keys) > 1:
            cam.keyframe_insert("location", frame=k["f"])
            if not tr:
                cam.keyframe_insert("rotation_euler", frame=k["f"])
            if "lens" in k:
                cd.keyframe_insert("lens", frame=k["f"])
    set_interp("BEZIER")
    force_interp(cam, c.get("interp", "BEZIER"))
    force_interp(cd, c.get("interp", "BEZIER"), "lens")


def apply_layout(sh, lay, scene, cam, holder, notes):
    links = {l["code"]: l for l in sh["links"]}
    cache, drivers, used = {}, {}, set()

    def linked(code, cname):
        key = (code, cname)
        if key not in cache:
            with bpy.data.libraries.load(links[code]["path"], link=True, relative=True) as (src, dst):
                if cname not in src.collections:
                    raise RuntimeError(f"{code}: no collection {cname} in {links[code]['path']}")
                dst.collections = [cname]
            cache[key] = dst.collections[0]
        return cache[key]

    for ent in lay.get("instances", []):
        code = ent["asset"]
        if code not in links:
            notes.append(f"{ent['name']}: asset {code} not linked (missing file)")
            continue
        used.add(code)
        coll = linked(code, ent.get("collection") or links[code]["collection"])
        if ent.get("override"):
            ov = coll.override_hierarchy_create(scene, bpy.context.view_layer, do_fully_editable=True)
            if ov.name in scene.collection.children:  # keep everything under ASSETS
                scene.collection.children.unlink(ov)
            holder.children.link(ov)
            objs = list(ov.all_objects)
            drv = find_part(objs, ent.get("root", f"{code}_root"))
            for pname, pspec in ent.get("parts", {}).items():
                po = find_part(objs, pname)
                if po is None:
                    notes.append(f"{ent['name']}: no part {pname}")
                    continue
                animate(po, pspec)
        else:
            drv = bpy.data.objects.new(ent["name"], None)
            drv.instance_type, drv.instance_collection = "COLLECTION", coll
            holder.objects.link(drv)
        drv["sg_instance"] = ent["name"]
        if ent.get("parent"):
            drv.parent = drivers[ent["parent"]]
        animate(drv, ent)
        drivers[ent["name"]] = drv
    for code in links:
        if code not in used:
            notes.append(f"{code}: linked but not placed by the recipe")

    c = lay.get("camera", {})
    keys = c.get("keys", [])
    setup_camera(cam, c, drivers)
    for alt in lay.get("alt_cameras", []):  # e.g. CAM_SH060_fix: the suggested fix, not the scene camera
        ac = bpy.data.objects.new(alt["name"], bpy.data.cameras.new(alt["name"]))
        scene.collection.objects.link(ac)
        setup_camera(ac, alt, drivers)
    cd = cam.data

    # board panels through the camera (viewport only, never rendered)
    set_interp("CONSTANT")
    for i, p in enumerate(lay.get("panels", [])):
        bg = cd.background_images.new()
        bg.image = bpy.data.images.load(p["image"], check_existing=True)
        bg.display_depth, bg.frame_method = "FRONT", "CROP"
        bg.alpha = p["alpha"][0][1]
        if len(p["alpha"]) > 1:
            for f, a in p["alpha"]:
                bg.alpha = a
                cd.keyframe_insert(f"background_images[{i}].alpha", frame=f)
    set_interp("BEZIER")
    force_interp(cd, "CONSTANT", "background_images")  # panel swaps are hard cuts
    cd.show_background_images = bool(lay.get("panels"))

    if lay.get("sound"):
        se = scene.sequence_editor_create()
        snd = lay["sound"]
        se.strips.new_sound("animatic_audio", snd["file"], 1, snd.get("frame", 0))
        scene.use_audio_scrub = True

    if lay.get("card"):
        for j, (line, size) in enumerate(lay["card"]["lines"]):
            cu = bpy.data.curves.new(f"CARD_{j}", "FONT")
            cu.body, cu.size, cu.align_x, cu.align_y = line, size, "CENTER", "CENTER"
            t = bpy.data.objects.new(f"CARD_{j}", cu)
            t.data.materials.append(blender_proxies.material("white"))
            t.parent = cam
            t.location = (0, 0.15 - j * 0.3, -3.0)
            scene.collection.objects.link(t)

    w = bpy.data.worlds.new(f"{scene.name}_world")
    w.color = lay.get("world", (0.7, 0.72, 0.75))
    scene.world = w
    workbench_look(scene, lay.get("sun"), lay.get("shadows", True))
    if lay.get("sun"):  # a real sun lamp too, for the lighting pass later
        lamp = bpy.data.objects.new("SUN", bpy.data.lights.new("SUN", "SUN"))
        d = Vector(scene.display.light_direction)  # points toward the sun
        lamp.rotation_euler = (-d).to_track_quat("-Z", "Y").to_euler()
        lamp["sun_az_el"] = lay["sun"]
        scene.collection.objects.link(lamp)
    if lay.get("notes"):
        bpy.data.texts.new("LAYOUT_NOTES").write(lay["notes"])
    scene.frame_set(scene.frame_start)
    return f"layout: {len(drivers)} placed, camera {len(keys)} keys, {len(lay.get('panels', []))} panels"


def build_shot(sh, job):
    fresh_file()
    scene = bpy.context.scene
    scene.name = sh["scene"]
    scene.frame_start, scene.frame_end = sh["frame_start"], sh["frame_end"]
    scene.frame_current = sh["frame_start"]
    set_fps(scene, job["fps"])
    scene.render.resolution_x, scene.render.resolution_y = job["res"]
    scene.render.resolution_percentage = 100

    cam = bpy.data.objects.new(sh["camera"], bpy.data.cameras.new(sh["camera"]))
    cam.location = (0, -12, 1.6)
    cam.rotation_euler = (math.radians(88), 0, 0)
    scene.collection.objects.link(cam)
    scene.camera = cam

    # save once first: relative library paths need the file to have a path
    os.makedirs(os.path.dirname(sh["path"]), exist_ok=True)
    save(sh["path"])

    holder = bpy.data.collections.new("ASSETS")
    scene.collection.children.link(holder)
    notes = []
    if sh.get("layout"):
        msg = apply_layout(sh, sh["layout"], scene, cam, holder, notes)
        if sh.get("missing"):
            notes.append("missing: " + ", ".join(sh["missing"]))
        bpy.ops.file.make_paths_relative()  # panels + sound were loaded by absolute path
        save(sh["path"])
        return msg + (f"; {'; '.join(notes)}" if notes else "")
    n = len(sh["links"])
    for i, link in enumerate(sh["links"]):
        want = link["collection"]
        with bpy.data.libraries.load(link["path"], link=True, relative=True) as (src, dst):
            if want not in src.collections:
                notes.append(f"{link['code']}: no collection {want} in file")
                continue
            dst.collections = [want]
        coll = dst.collections[0]
        inst = bpy.data.objects.new(want, None)
        inst.instance_type = "COLLECTION"
        inst.instance_collection = coll
        inst.location.x = (i - (n - 1) / 2) * 2.5  # side by side, centred on the camera
        holder.objects.link(inst)
    if sh.get("missing"):
        notes.append("missing: " + ", ".join(sh["missing"]))
    save(sh["path"])
    return f"{n - sum(1 for x in notes if 'no collection' in x)} assets linked" + (f"; {'; '.join(notes)}" if notes else "")


def main():
    job = json.load(open(sys.argv[sys.argv.index("--") + 1], encoding="utf-8"))
    results = []

    def run(kind, item, fn):
        if os.path.exists(item["path"]):  # never overwrite
            results.append({"kind": kind, "path": item["path"], "status": "exists", "msg": "file already there"})
            return
        try:
            msg = fn()
            results.append({"kind": kind, "path": item["path"], "status": "ok", "msg": msg})
        except Exception as e:
            traceback.print_exc()
            if os.path.exists(item["path"]):  # half-saved file from this run: remove it so a rerun tries again
                os.remove(item["path"])
            results.append({"kind": kind, "path": item["path"], "status": "failed", "msg": f"{type(e).__name__}: {e}"})
        print(f"[reel-room] {kind} {results[-1]['status']}: {item['path']}", flush=True)
        with open(job["results"], "w", encoding="utf-8") as fh:  # keep partial results if Blender dies
            json.dump(results, fh, indent=1)

    for st in job["stubs"]:
        run("asset", st, lambda st=st: build_stub(st))
    for sh in job["shots"]:
        run("shot", sh, lambda sh=sh: build_shot(sh, job))
    with open(job["results"], "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=1)


main()
